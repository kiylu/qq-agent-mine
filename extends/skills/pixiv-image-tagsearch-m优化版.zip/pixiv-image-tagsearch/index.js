// Pixiv「来张图」—— 按角色搜插画并发到当前会话，带 PID 索引去重
//
// 为什么 shell 出 curl 而不是用 api.fetch：
//   Pixiv 在国内必须走代理，而 Node 的 undici（globalThis.fetch）**不支持 socks5**，
//   只认 http(s) 代理，所以这里走 `curl --proxy socks5h://...`。
//   curl.exe 是 Windows 10 1803+ 自带的，无需额外安装。
//
// 核心设计：
//   1. 【选前过滤】爬过的作品（按 Pixiv 作品 ID 判定）在**挑选之前**就剔掉，
//      而不是挑完再逐个检查。后者在候选全是旧图时会空手而归、直接报失败。
//   2. 【PID 索引】<数据目录>/pixiv/pid-index.json 记录每个爬过的作品：
//      {pid: {file, folder, tags, author, title, bookmarks, likes,
//             firstSeen, lastSeen, sentCount, lastSent}}。
//      O(1) 查询，能回答"这张以前发过没、谁画的"。原子写，断电不会毁掉整个索引。
//      另有**目录扫描兜底**：按文件名里的 hash 后缀找已存在的文件，
//      这样从别的机器人迁移过来的图库也能被识别为"已入库"。
//   3. 【候选耗尽时降级】新图找完了就明说"这些是以前存过的"，而不是报失败。
//
// tag 翻译：模型在 tag 参数里直接给日文标签（它认识东方角色），工具把映射记进
// tag-dict.json，下次命中零成本。也支持从别处导入既有词典（见 legacyTagDict 设置）。
//
// v1.2.0 新增两件事：
//   4. 【标签规范化】pixiv 的 tag 搜索没有模糊匹配，输入错一个字就是 0 结果，
//      部分一致还会混进大量"只是提了一嘴"的作品。搜索前先用 Pixiv 搜索框同款的
//      联想接口（/rpc/cps.php，免登录）把输入校正成规范日文标签——中文直接就能
//      识别（古明地恋→古明地こいし），再用 s_mode=s_tag_full 完全一致检索。
//   5. 【R18】Pixiv 规定匿名请求拿不到 R18：实测 mode=all/r18 参数会被静默忽略，
//      三种 mode 返回同一批全年龄结果。想搜到 R18 必须在设置里配 PHPSESSID
//      （浏览器登录后复制），搜索和详情请求带上 Cookie 即可；图片下载不需要
//      登录（i.pximg.net 只看 Referer），所以 Cookie 只用于检索。

import { execFile, spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const PIXIV_REFERER = 'https://www.pixiv.net/';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';
// Windows 用系统自带的 curl.exe（10 1803+）；Linux/macOS 直接叫 curl
const CURL_BIN = process.platform === 'win32' ? 'curl.exe' : 'curl';
const IMG_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp']);
const MAX_CANDIDATES = 24;
// 设了收藏门槛时，候选池必须更大，才有可能碰到"够老、收藏够多"的作品——
// 搜索用的是 order=date_d（最新优先），新图天然还没攒到收藏。
// 上限跟随「搜索翻页数」（pages×24，最多 120）；翻页数=1 时与旧行为完全一致。
const MAX_CANDIDATES_WITH_THRESHOLD = 120;

let cfg = () => ({});
let log = () => {};

// ── 数据目录（与程序其它数据同源，跟着一起备份）──────────────────────
function dataDir() {
  const base = process.env.QQ_AGENT_DATA_DIR
    || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..', 'data');
  return path.join(base, 'pixiv');
}

// ── PID 索引 ────────────────────────────────────────────────────────
let ledger = null;

function ledgerFile() { return path.join(dataDir(), 'pid-index.json'); }

function loadLedger() {
  if (ledger) return ledger;
  try {
    const raw = JSON.parse(fs.readFileSync(ledgerFile(), 'utf8'));
    ledger = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
  } catch {
    ledger = {};
  }
  return ledger;
}

function saveLedger() {
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    // 原子写：断电/崩溃时不会留下半截 JSON 把整个索引毁掉
    const p = ledgerFile();
    fs.writeFileSync(`${p}.tmp`, JSON.stringify(ledger, null, 2), 'utf8');
    fs.renameSync(`${p}.tmp`, p);
  } catch { /* 索引写不进去不该让这次爬图失败 */ }
}

function hasPid(pid) { return Boolean(loadLedger()[String(pid)]); }

function recordPid(pid, info = {}) {
  const l = loadLedger();
  const k = String(pid);
  const prev = l[k] || {};
  const sent = Boolean(info.sent);
  l[k] = {
    pid: Number(pid) || pid,
    file: info.file ?? prev.file ?? '',
    folder: info.folder ?? prev.folder ?? '',
    tags: info.tags ?? prev.tags ?? [],
    // 作品信息也一并存档：以后要回答"这张谁画的""有没有发过"时不用再联网查
    author: info.author ?? prev.author ?? '',
    title: info.title ?? prev.title ?? '',
    bookmarks: info.bookmarks ?? prev.bookmarks ?? 0,
    likes: info.likes ?? prev.likes ?? 0,
    firstSeen: prev.firstSeen || Date.now(),
    lastSeen: Date.now(),
    sentCount: (prev.sentCount || 0) + (sent ? 1 : 0),
    lastSent: sent ? Date.now() : (prev.lastSent || 0)
  };
  saveLedger();
}

// ── tag 词典（中/英 → Pixiv 日文标签）────────────────────────────────
let tagDict = null;

function tagDictFile() { return path.join(dataDir(), 'tag-dict.json'); }

function loadTagDict() {
  if (tagDict) return tagDict;
  tagDict = {};
  try {
    // 首次运行：如果配置了外部词典（从别的机器人迁移过来的），导入一次，已有翻译不浪费。
    // 两种格式都认：{"古明地恋": "古明地こいし"} 和 {"古明地恋": {"ja": "古明地こいし"}}
    const legacyPath = String(cfg()?.legacyTagDict || '').trim();
    if (!fs.existsSync(tagDictFile()) && legacyPath && fs.existsSync(legacyPath)) {
      const legacy = JSON.parse(fs.readFileSync(legacyPath, 'utf8'));
      for (const [name, v] of Object.entries(legacy || {})) {
        const ja = typeof v === 'string' ? v : (v && v.ja);
        if (ja) tagDict[name] = String(ja);
      }
      saveTagDict();
    } else {
      const raw = JSON.parse(fs.readFileSync(tagDictFile(), 'utf8'));
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) tagDict = raw;
    }
  } catch { tagDict = {}; }
  return tagDict;
}

function saveTagDict() {
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    fs.writeFileSync(tagDictFile(), JSON.stringify(tagDict, null, 2), 'utf8');
  } catch { /* 同上，不影响本次 */ }
}

function rememberTag(name, ja) {
  const n = String(name || '').trim();
  const j = String(ja || '').trim();
  if (!n || !j || n === j) return;
  const d = loadTagDict();
  if (d[n] === j) return;
  d[n] = j;
  saveTagDict();
}

// ── curl 封装 ───────────────────────────────────────────────────────
function curl(url, { proxy = '', referer = '', timeoutMs = 25000, binary = false, cookie = '' } = {}) {
  return new Promise((resolve, reject) => {
    const args = ['-sS', '-L', '--max-time', String(Math.max(3, Math.ceil(timeoutMs / 1000)))];
    if (proxy) args.push('--proxy', proxy);
    args.push('-H', `User-Agent: ${UA}`);
    args.push('-H', `Referer: ${referer || PIXIV_REFERER}`);
    // 不带 Accept-Language 时，标签联想接口（cps.php）只把输入原样返回一个
    // "prefix" 候选，不给出翻译和真正的模糊联想——这个头是联想功能的开关
    args.push('-H', 'Accept-Language: zh-CN,zh;q=0.9');
    if (cookie) args.push('-H', `Cookie: ${cookie}`);
    args.push('-H', 'X-Requested-With: XMLHttpRequest');
    args.push(url);
    execFile(CURL_BIN, args, {
      maxBuffer: 48 * 1024 * 1024,
      encoding: binary ? 'buffer' : 'utf8',
      windowsHide: true,
      timeout: timeoutMs + 8000
    }, (err, stdout) => {
      if (err) return reject(err);
      resolve(stdout);
    });
  });
}

// ── 代理保活（移植自 char_img.py 的 _proxy_port_open / _ensure_proxy）──
//
// 注意：这套东西叫 v2rayN，但**核心是 sing-box** —— v2rayN 生成的
// binConfigs\config.json 是 sing-box 格式，所以原版启的是
// bin\sing_box\sing-box.exe run -c <config>，不是 xray。
// 配置里的入站是 mixed 类型监听 127.0.0.1:10808，socks5 和 http 共用这一个口。
let lastEnsureTs = 0;
let lastEnsureOk = null;
let ensureInFlight = null;

/** 代理地址里抽出可探测的 host:port（socks5h://127.0.0.1:10808 → 127.0.0.1:10808） */
function proxyHostPort(proxy) {
  const s = String(proxy || '').trim();
  if (!s) return null;
  const m = /^(?:[a-z0-9+.-]+:\/\/)?([^:/@]+):(\d+)/i.exec(s);
  if (!m) return null;
  return { host: m[1], port: Number(m[2]) };
}

function probeTcp(host, port, timeoutMs = 800) {
  return new Promise((resolve) => {
    const sock = net.connect({ host, port });
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      sock.destroy();
      resolve(ok);
    };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => finish(true));
    sock.once('timeout', () => finish(false));
    sock.once('error', () => finish(false));
  });
}

async function waitPort(host, port, totalMs) {
  const deadline = Date.now() + totalMs;
  while (Date.now() < deadline) {
    if (await probeTcp(host, port, 600)) return true;
    await new Promise((r) => setTimeout(r, 700));
  }
  return false;
}

/**
 * 确保代理端口可连。端口没开且开了 autoStart 时，后台静默拉起 sing-box。
 * 返回 { ok, started, reason }。
 *
 * 节流 60s + 单飞（in-flight）锁：群聊里连着几个人要图时，
 * 不能每个请求都去 spawn 一次核心 —— 第二次 spawn 会因端口占用直接失败。
 */
async function ensureProxy({ proxy, autoStart, coreDir }) {
  const hp = proxyHostPort(proxy);
  if (!hp) return { ok: false, started: false, reason: '代理地址解析不出来' };

  if (await probeTcp(hp.host, hp.port)) {
    lastEnsureOk = true;
    return { ok: true, started: false };
  }
  if (!autoStart) {
    return { ok: false, started: false, reason: `代理端口 ${hp.host}:${hp.port} 没在监听，且未开启自动拉起` };
  }
  if (ensureInFlight) return ensureInFlight;                 // 已有一次在跑，搭车
  if (Date.now() - lastEnsureTs < 60000 && lastEnsureOk === false) {
    return { ok: false, started: false, reason: '60 秒内已尝试过拉起代理且失败，先不重复试' };
  }
  lastEnsureTs = Date.now();

  ensureInFlight = (async () => {
    const dir = String(coreDir || '').trim();
    const exe = dir ? path.join(dir, 'bin', 'sing_box', 'sing-box.exe') : '';
    const conf = dir ? path.join(dir, 'binConfigs', 'config.json') : '';
    if (!dir || !fs.existsSync(exe) || !fs.existsSync(conf)) {
      lastEnsureOk = false;
      return { ok: false, started: false, reason: `找不到 sing-box 核心或配置（${dir || '未配置 proxyCoreDir'}）` };
    }
    try {
      const child = spawn(exe, ['run', '-c', conf], {
        cwd: path.dirname(exe),
        detached: true,          // 代理是基础设施，不跟着 QQ Agent 一起死
        stdio: 'ignore',         // 不弹窗、不占管道
        windowsHide: true
      });
      child.unref();
    } catch (e) {
      lastEnsureOk = false;
      return { ok: false, started: false, reason: `启动 sing-box 失败：${e?.message ?? e}` };
    }
    const up = await waitPort(hp.host, hp.port, 15000);
    lastEnsureOk = up;
    return up
      ? { ok: true, started: true }
      : { ok: false, started: true, reason: 'sing-box 已启动，但 15 秒内端口仍未就绪' };
  })();

  try { return await ensureInFlight; } finally { ensureInFlight = null; }
}

// ── Pixiv 工具函数（照抄原版语义）────────────────────────────────────
function pixivWorkId(url) {
  const m = /(\d{5,12})_p\d+_/.exec(String(url || ''));
  return m ? m[1] : null;
}

function imageHash(url, workId = null) {
  const key = workId ? `pixiv:${workId}` : String(url);
  return crypto.createHash('md5').update(key, 'utf8').digest('hex').slice(0, 8);
}

function normalizeExt(url) {
  const ext = path.extname(String(url).split('?')[0]).toLowerCase();
  return IMG_EXT.has(ext) ? ext : '.png';
}

/** 旧文件兜底：目录里已有同 hash 的文件就复用它（兼容原图库的命名） */
function findExistingFile(dir, hash, ext) {
  try {
    for (const f of fs.readdirSync(dir)) {
      if (f.endsWith(ext) && f.includes(`_${hash}${ext}`)) return path.join(dir, f);
    }
  } catch { /* 目录不存在 */ }
  return null;
}

// ── 标签规范化：把中文/别名/部分输入校正成 Pixiv 规范日文标签 ─────────
// 用的是 Pixiv 搜索框联想的公开接口 /rpc/cps.php（免登录可用）。
// 候选带 tag_name（日文标签）、tag_translation（中文翻译）、access_count（热度），
// 实测：古明地恋→古明地こいし、博丽灵梦→博麗霊夢、琪露诺→チルノ、芙兰朵露→フランドール。
// 注意：pixiv 上也存在"中文原样当标签"的情况（如 博丽灵梦 本身是个标签），
// 但热度通常比规范日文标签低一到两个数量级，所以**中文翻译精确命中优先于同名标签**。

/** 平假名→片假名（联想输入 こい 也能包住 コイカツ 这类片假名标签） */
function hiraToKata(s) {
  return String(s || '').replace(/[\u3041-\u3096]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

/**
 * 返回 { tag, candidates } 或 null（联想失败/没有可信候选，调用方回落原始输入）。
 * candidates 原样带回，"没搜到"时可以用它给用户列相近标签。
 */
async function canonicalizeTag(input, { proxy, timeoutMs, cookie }) {
  try {
    const raw = await curl(`https://www.pixiv.net/rpc/cps.php?keyword=${encodeURIComponent(input)}`, { proxy, timeoutMs, cookie });
    const cands = (JSON.parse(raw)?.candidates || [])
      .map((x) => ({ tag: String(x.tag_name || '').trim(), zh: String(x.tag_translation || '').trim(), count: Number(x.access_count) || 0 }))
      .filter((x) => x.tag);
    if (!cands.length) return null;

    const pick = (list) => list.reduce((m, x) => (x.count > m.count ? x : m));
    // ① 中文翻译精确命中（「古明地恋」= 古明地こいし 的翻译）
    const zhExact = cands.filter((x) => x.zh === input);
    if (zhExact.length) return { tag: pick(zhExact).tag, candidates: cands };
    // ② 输入本身就是规范标签 → 原样保留
    if (cands.some((x) => x.tag === input)) return { tag: input, candidates: cands };
    // ③ 包含关系兜底（假名归一 + 中文翻译包含），都没有就承认失败
    const ni = hiraToKata(input).toLowerCase();
    const contain = cands.filter((x) => hiraToKata(x.tag).toLowerCase().includes(ni) || (x.zh && x.zh.includes(input)));
    if (contain.length) return { tag: pick(contain).tag, candidates: cands };
    return null;
  } catch {
    return null;   // 联想挂了不该挡住搜索，回落原始输入照常搜
  }
}

// ── 登录态探测（PHPSESSID 是否真的有效）──────────────────────────────
// 背景：Pixiv 对匿名请求会**静默忽略** mode=all/r18 参数（返回同一批全年龄
// 结果），cookie 失效和没配置在外表上看一模一样，用户根本没法排查。
// /ajax/user/extra 是最轻的探针：未登录 error:true，登录 error:false。
let loginProbeCache = null;   // { key: cookie串, ok, at } —— 按 cookie 值缓存，换 cookie 立刻失效

/** 返回 'no-cookie' | 'invalid' | 'ok'（进程内缓存 5 分钟，群聊连续要图不会每次都探） */
async function probeLoginState(cookie, { proxy, timeoutMs, apiBase }) {
  if (!cookie) return 'no-cookie';
  if (loginProbeCache && loginProbeCache.key === cookie && Date.now() - loginProbeCache.at < 5 * 60000) {
    return loginProbeCache.ok ? 'ok' : 'invalid';
  }
  let ok = false;
  try {
    const d = JSON.parse(await curl(`${apiBase}/ajax/user/extra?lang=zh`, { proxy, timeoutMs, cookie }));
    ok = d?.error === false;
  } catch { ok = false; }
  loginProbeCache = { key: cookie, ok, at: Date.now() };
  return ok ? 'ok' : 'invalid';
}

/** R18 能力探测：拿「R-18」这个百万级作品的大标签搜 mode=r18，看结果里是否真有 R18 作品 */
async function probeR18(cookie, { proxy, timeoutMs, apiBase }) {
  try {
    const kw = encodeURIComponent('R-18');
    const url = `${apiBase}/ajax/search/illustrations/${kw}?word=${kw}&order=date_d&mode=r18&p=1&s_mode=s_tag_full&type=all&lang=zh`;
    const d = JSON.parse(await curl(url, { proxy, timeoutMs, cookie }));
    return (d?.body?.illust?.data || []).some((x) => Number(x?.xRestrict) > 0);
  } catch { return false; }
}

/**
 * 取**一页**搜索结果（不含详情，所以此时还没有收藏数）。
 * 拆成"一页一取"是为了让调用方"够用就停"——每多一个候选就多一次详情请求。
 */async function searchPage(query, page, opt) {
  const { proxy, timeoutMs, mode, type, skipMultiPage, apiBase, cookie, sMode = 's_tag' } = opt;
  const kw = encodeURIComponent(query);
  const url = `${apiBase}/ajax/search/illustrations/${kw}`
    + `?word=${kw}&order=date_d&mode=${mode}&p=${page}&s_mode=${sMode}&type=${type}&lang=zh`;
    let data;
    // ⚠️ cookie 必须带上：搜索是 R18 的唯一关口（图片 CDN 反而不需要）。
    // v1.2.0 曾漏传这里，导致搜索一直匿名、mode=r18 被静默忽略——而登录探针
    // 和详情请求都正常，问题被完美掩盖（v1.2.1 排查"r18 不生效"时才现形）。
    try { data = JSON.parse(await curl(url, { proxy, timeoutMs, cookie })); } catch { return []; }
  const body = data?.body || {};
  const items = body.illust?.data || body.illustManga?.data || [];
  const out = [];
  for (const it of items) {
    const id = String(it?.id ?? '');
    if (!id) continue;
    let u = it?.urls?.regular || it?.url || '';
    if (!u) continue;
    // 缩略图 -> master1200 大图
    u = u.replace('/c/250x250_80_a2/', '/').replace('_square1200.', '_master1200.');
    const pageCount = Number(it?.pageCount) || 1;
    if (skipMultiPage && pageCount > 1) continue;
    const tags = (Array.isArray(it?.tags) ? it.tags : [])
      .map((t) => (t && typeof t === 'object' ? t.tag : String(t || '')))
      .filter(Boolean);
    out.push({ id, url: u, bookmarks: 0, likes: 0, pageCount, tags, xRestrict: Number(it?.xRestrict) || 0 });
  }
  // 每页搜索都留痕：排查"r18 不生效"这类问题时，mode/sMode/R18 占比一看便知
  log('搜索「%s」p%s mode=%s s_mode=%s → %s 条（R18 占 %s）', query, page, mode, sMode, out.length, out.filter((x) => x.xRestrict > 0).length);
  return out;
}

/** 并发拉详情补收藏量/点赞量（原版用 6 线程，这里用 6 个协程等价实现） */
async function fetchDetails(cands, { proxy, timeoutMs, apiBase, cookie }) {
  let cursor = 0;
  const worker = async () => {
    while (cursor < cands.length) {
      const c = cands[cursor++];
      try {
        const d = JSON.parse(await curl(`${apiBase}/ajax/illust/${c.id}`, { proxy, timeoutMs, cookie }));
        const b = d?.body || {};
        c.bookmarks = Number(b.bookmarkCount) || 0;
        c.likes = Number(b.likeCount) || 0;
        // 发图时要把这些一并带出去，所以在这一趟里取全（详情接口本来就返回了）
        c.author = String(b.userName || '').trim();
        c.authorId = String(b.userId || '').trim();
        c.title = String(b.title || '').trim();
        c.views = Number(b.viewCount) || 0;
        c.created = String(b.createDate || '').trim();
      } catch { /* 单张失败就保持 0，不拖垮整批 */ }
    }
  };
  await Promise.all(Array.from({ length: Math.min(6, cands.length) }, worker));
}

/** 按收藏+点赞加权不放回抽样（权重越大概率越高） */
function weightedSelect(items, n) {
  const pool = [...items];
  const picked = [];
  while (picked.length < n && pool.length) {
    const weights = pool.map((it) => Math.max(Number(it.bookmarks) || 0, 0) + Math.max(Number(it.likes) || 0, 0) + 1);
    const total = weights.reduce((a, b) => a + b, 0);
    let r = Math.random() * total;
    let chosen = null;
    for (let i = 0; i < pool.length; i++) {
      r -= weights[i];
      if (r <= 0) { chosen = pool.splice(i, 1)[0]; break; }
    }
    picked.push(chosen || pool.pop());
  }
  return picked;
}

async function downloadImage(url, destDir, { proxy, timeoutMs, name, workId, pageCount = 1 }) {
  fs.mkdirSync(destDir, { recursive: true });
  let realUrl = url;
  if (pageCount > 1) {
    const idx = Math.floor(Math.random() * pageCount);
    realUrl = url.replace(/_p\d+_/, `_p${idx}_`);
  }
  const ext = normalizeExt(realUrl);
  const hash = imageHash(realUrl, workId);

  const existing = findExistingFile(destDir, hash, ext);
  if (existing) return { file: existing, reused: true };

  const safe = String(name || 'img').replace(/[^\w\u4e00-\u9fff-]/g, '_').slice(0, 30) || 'img';
  const dest = path.join(destDir, `${Date.now()}_${safe}_${hash}${ext}`);
  const buf = await curl(realUrl, { proxy, referer: PIXIV_REFERER, timeoutMs, binary: true });
  if (!buf || buf.length < 200) return null;   // 太小的基本是错误页
  fs.writeFileSync(dest, buf);
  return { file: dest, reused: false };
}

// ── 发图时附带的作品信息 ─────────────────────────────────────────────
/** 把万位数压成「1.2万」，聊天里比 12345 好读 */
function compactNum(n) {
  const v = Number(n) || 0;
  if (v < 10000) return String(v);
  return `${(v / 10000).toFixed(v >= 100000 ? 0 : 1).replace(/\.0$/, '')}万`;
}

function formatInfo(it) {
  const title = String(it.title || '').replace(/\s+/g, ' ').trim().slice(0, 40);
  const head = title ? `🎨 ${title}` : `🎨 pixiv #${it.id}`;
  // xRestrict: 1=R18, 2=R18G（搜索结果自带，无需额外请求）
  const adult = Number(it.xRestrict) === 1 ? 'R18' : (Number(it.xRestrict) === 2 ? 'R18G' : '');
  const bits = [];
  if (adult) bits.push(`🔞 ${adult}`);
  if (it.author) bits.push(`👤 ${it.author}`);
  if (it.bookmarks) bits.push(`❤️ ${compactNum(it.bookmarks)}`);
  if (it.likes) bits.push(`⭐ ${compactNum(it.likes)}`);
  if (it.views) bits.push(`👁 ${compactNum(it.views)}`);
  bits.push(`#${it.id}`);
  return `${head}\n${bits.join(' ｜ ')}`;
}

// ── 工具注册 ────────────────────────────────────────────────────────
export function setup(api) {
  cfg = api.config;
  log = api.log;
  const d = loadLedger();
  const dict = loadTagDict();
  api.log(`Pixiv 技能已注册｜索引 ${Object.keys(d).length} 个 PID｜tag 词典 ${Object.keys(dict).length} 条`);

  api.registerTool({
    id: 'pixiv_image_tag',
    name: 'Pixiv 来张图（标签检索）',
    description:
      '从 Pixiv 按角色搜一张**高收藏**插画并发到当前会话：先把角色名自动校正成 Pixiv 规范标签再精确检索（中文/日文都行），优先走「N users入り」约定标签攒够收藏的作品，不够再回落普通检索；爬过的作品不会重复爬。' +
      '当群友说「来张 XX」「来一张 XX」「找张 XX」，或想要「高收藏/热门」的图时调用。' +
      'character 填角色名即可（中文会自动校正成日文标签）；确定日文标签的话填进 tag 参数更稳。群友明确要 R18 内容时才把 r18 参数设为 true（需要技能设置里配置 PHPSESSID 才真的有效）。',
    category: 'media',
    icon: '🖼️',
    parameters: {
      type: 'object',
      properties: {
        character: { type: 'string', description: '角色名，中文或日文都可以，例如「古明地恋」「古明地こいし」。会自动校正成 Pixiv 规范标签。' },
        tag: {
          type: 'string',
          description: '可选。确定的日文标签直接填；中文或部分输入也可以，会自动规范化。多个标签用空格分隔表示 AND。'
        },
        count: { type: 'number', description: '发几张，1~3，默认 1。' },
        r18: { type: 'boolean', description: '仅当群友明确要求 R18/涩图内容时才传 true：只搜 R18 作品。需要技能设置里配置了 PHPSESSID 才有效。默认 false，跟随技能设置的内容分级。' }
      },
      required: ['character']
    },
    async execute(ctx, args) {
      const c = cfg() || {};
      const apiBase = String(c.apiBase || 'https://www.pixiv.net').trim().replace(/\/+$/, '');
      const proxy = String(c.proxy || '').trim();
      // 留空 = 存到程序数据目录下，随数据一起备份，开箱即用
      const imageDir = String(c.imageDir || '').trim() || path.join(dataDir(), 'images');
      const minBm = Math.max(0, Number(c.minBookmarks) || 0);
      // 上限从 3 放宽到 10：以前设 5 会被静默夹成 3，翻页等于没生效
      const pages = Math.min(10, Math.max(1, Number(c.candidatePages) || 3));
      const skipMultiPage = c.skipMultiPage !== false;
      const mode = String(c.mode || 'safe').trim();
      const type = String(c.type || 'artwork').trim();
      const timeoutMs = Math.min(60000, Math.max(5000, Number(c.timeoutMs) || 25000));
      // PHPSESSID：Pixiv 匿名拿不到 R18（实测 mode 参数会被静默忽略），登录凭据只在检索时带上；
      // 图片 CDN 只看 Referer，下载不需要它
      const phpsessid = String(c.phpsessid || '').trim();
      const cookie = phpsessid ? `PHPSESSID=${phpsessid}` : '';
      const useSuggest = c.useTagSuggest !== false;

      const character = String(args?.character ?? '').trim();
      if (!character) return { content: '缺少 character：请告诉我要哪个角色的图。', isError: true };

      const count = Math.min(3, Math.max(1, Number(args?.count) || 1));
      // 按次要 R18：仅当群友明确要求时模型才传 true，否则跟随全局 mode 设置
      const effectiveMode = args?.r18 === true ? 'r18' : mode;

      // tag 解析：模型给的日文标签 > 词典 > 原名直接用
      const dict = loadTagDict();
      const given = String(args?.tag ?? '').trim();
      let jaTag = given || dict[character] || character;
      if (given) rememberTag(character, given);

      // 代理可能没开：先探测，必要时按设置把 sing-box 拉起来。
      // 代理留空 = 直连（本机能访问 Pixiv 即可），此时跳过探测。
      if (proxy) {
        const pre = await ensureProxy({
          proxy,
          autoStart: c.autoStartProxy === true,
          coreDir: String(c.proxyCoreDir || '').trim()
        });
        if (!pre.ok) {
          return {
            content: `拿不到图：${pre.reason}。请在技能设置里把代理开起来，或打开「代理没开时自动拉起」；本机能直连 Pixiv 的话也可以把代理地址留空。`,
            isError: true
          };
        }
      }

      // ── 登录态探测：非 safe 模式先确认 PHPSESSID 到底能不能用 ─────────
      // 不探的话，cookie 失效/没配置和"正常全年龄结果"在外表上一模一样，
      // 用户只会觉得"r18 不生效"而没法排查（v1.2.0 上线后实际踩过）。
      let loginState = 'no-cookie';   // no-cookie | invalid | ok
      if (effectiveMode !== 'safe') {
        loginState = await probeLoginState(cookie, { proxy, timeoutMs, apiBase });
        if (effectiveMode === 'r18' && loginState === 'invalid') {
          return {
            content: '拿不到 R18 图：PHPSESSID 已失效（Pixiv 那边认为未登录），匿名请求拿不到 R18。'
              + '请回浏览器重新复制一次 PHPSESSID（F12 → Application → Cookie → https://www.pixiv.net），'
              + '填进技能设置的「Pixiv 登录凭据(PHPSESSID)」；也可以对机器人说「检查 pixiv cookie」让它自检。',
            isError: true
          };
        }
      }

      // ── 标签规范化：中文/别名/部分输入 → 规范日文标签 ──────────────────
      // pixiv 的 tag 搜索没有模糊匹配：输错一个字就是 0 结果，部分一致又会混进
      // 大量"只是提了一嘴"的作品。先用联想接口校准，再用完全一致检索（s_tag_full）。
      const rawTag = jaTag;
      let sMode = 's_tag';
      let canon = null;
      if (useSuggest) {
        canon = await canonicalizeTag(rawTag, { proxy, timeoutMs, cookie });
        if (canon?.tag && canon.tag !== rawTag) {
          log('标签规范化：%s → %s', rawTag, canon.tag);
          jaTag = canon.tag;
          rememberTag(character, jaTag);   // 校准结果进词典，下次同一角色零成本
        }
        if (canon) sMode = 's_tag_full';
      }

      const t0 = Date.now();
      // ── 逐页搜索 + 逐页补详情，"够挑了"就停 ──────────────────────────
      // 旧实现的两个坑（收藏门槛形同虚设的直接原因）：
      //   ① 一次只收 24 个候选（MAX_CANDIDATES 写死），而搜索是"最新优先"——
      //      新图还没攒到收藏，24 个里几乎必然一个都不达标；
      //   ② 候选池只有 24 时，「搜索翻页数」调到 5 也毫无作用（第 1 页就填满了）。
      // 现在：设了门槛就按 pages×24（上限 120）翻，且一旦"达标候选够挑"立刻收工，
      // 不会无脑把请求数打满。
      // ── 检索词：设了门槛就优先用 Pixiv 的约定标签「{N}users入り」──────
      // 为什么必须这么做（都是实测结论）：
      //   · 搜索接口只给"最新优先"；order=popular_d（按热度）和 blt（收藏数筛选）
      //     在**匿名请求下会被 Pixiv 直接忽略** —— 五种写法返回的是同一批结果。
      //   · 于是大流量标签下，最新的一两百个作品收藏都还在几百徘徊
      //     （实测「初音ミク」翻 5 页 142 个候选，最高 444）。
      //   · 而「500users入り」这类标签是**上传者自己打的**，不受该限制：
      //     实测「初音ミク 500users入り」前 5 个收藏 = 754/881/775/531/839。
      // 注意：它只是"更容易捞到"，不保证 100%（有人会乱打标签），
      // 所以下面按真实收藏数复核的那道门槛照样保留。
      const iriSteps = [500, 1000, 5000, 10000, 30000];
      const queries = [jaTag];
      if (minBm >= 500 && c.usePopularTag !== false) {
        const step = [...iriSteps].reverse().find((s) => s <= minBm);
        if (step) queries.unshift(jaTag + ' ' + step + 'users入り');
      }
      // 规范化改写过输入时，把原始输入留作最后兜底（仍用部分一致搜）
      if (rawTag !== jaTag) queries.push(rawTag);
      if (queries.length > 1) log('检索顺序：先「%s」，不够再回落「%s」', queries[0], queries[1]);

      const limit = minBm > 0
        ? Math.min(MAX_CANDIDATES_WITH_THRESHOLD, Math.max(MAX_CANDIDATES, pages * MAX_CANDIDATES))
        : MAX_CANDIDATES;
      const wantPool = Math.max(1, count) * 3;
      let cands = [];
      const seenIds = new Set();
      try {
        search:
        for (const query of queries) {
          for (let page = 1; page <= pages; page++) {
            // 规范标签用完全一致（s_tag_full）结果更干净；「N users入り」组合词和
            // 原始输入兜底必须用部分一致（s_tag）——组合词不是单个标签，完全一致搜不到
            const got = (await searchPage(query, page, {
              proxy, timeoutMs, mode: effectiveMode, type, skipMultiPage, apiBase, cookie,
              sMode: query === jaTag ? sMode : 's_tag'
            }))
              .filter((x) => !seenIds.has(x.id) && seenIds.add(x.id));
            if (!got.length) break;
            await fetchDetails(got, { proxy, timeoutMs, apiBase, cookie });
            cands = cands.concat(got);
            const okCount = minBm > 0 ? cands.filter((x) => (Number(x.bookmarks) || 0) >= minBm).length : 0;
            if (minBm > 0 && okCount >= wantPool) break search;   // 够挑了，收工
            if (cands.length >= limit) break search;
          }
        }
      } catch (e) {
        const msg = String(e?.message || e);
        if (/could not resolve|Failed to connect|Connection refused|proxy/i.test(msg)) {
          return {
            content: '连不上 Pixiv（' + msg + '）。这个功能必须走代理，请确认代理已启动，'
              + '当前设置是「' + (proxy || '直连') + '」。',
            isError: true
          };
        }
        return { content: '搜索 Pixiv 失败：' + msg, isError: true };
      }
      if (!cands.length) {
        // 联想接口给过候选的话，顺手列几个相近标签，省得群友干等一轮"没搜到"
        const sugg = (canon?.candidates || []).filter((x) => x.tag !== jaTag).slice(0, 3)
          .map((x) => (x.zh ? `${x.tag}（${x.zh}）` : x.tag));
        const hint = effectiveMode !== 'safe'
          ? (loginState === 'no-cookie'
            ? '注意：没配置「Pixiv 登录凭据(PHPSESSID)」时，Pixiv 匿名搜索拿不到 R18 内容，内容分级设置实际不生效。'
            : loginState === 'invalid'
              ? 'PHPSESSID 已失效（Pixiv 认为未登录），R18 搜不到；回浏览器重新复制一次即可。'
              : 'PHPSESSID 有效。若 R18 一直搜不到，检查 pixiv 账号设置里的「阅览限制(R18)」是否开启。')
          : '';
        return {
          content: `没搜到「${rawTag}」的图${jaTag !== rawTag ? `（已自动规范化为「${jaTag}」，同样没搜到）` : ''}`
            + (sugg.length ? `。Pixiv 联想的相近标签：${sugg.join('、')}` : '')
            + (hint ? `。${hint}` : '')
            + '。可以换个更具体、更常用的名字再试一次。',
          isError: true
        };
      }

      // ── 收藏门槛 ──────────────────────────────────────────────────────
      // 旧行为是"候选全被卡掉就放宽"（有图总比没有强），但后果很隐蔽：
      // 门槛形同虚设，而且**没有任何人知道**——群里只会看到一张低于门槛的图。
      // 现在两种模式，且放宽时一定会标注（群消息 + 工具结果 + 日志）：
      //   strictMinBookmarks = true  绝不发低于门槛的图，改为明确说明"没找到"
      //   strictMinBookmarks = false 照旧放宽，但写明"未达门槛，已放宽"
      const strict = c.strictMinBookmarks === true;
      let pool = minBm > 0 ? cands.filter((x) => x.bookmarks >= minBm) : cands;
      let relaxNote = '';
      if (minBm > 0 && !pool.length) {
        const top = cands.reduce((m, x) => Math.max(m, Number(x.bookmarks) || 0), 0);
        const noData = cands.every((x) => !(Number(x.bookmarks) > 0));
        if (strict) {
          log(`收藏门槛未满足：翻了 ${cands.length} 个候选，最高 ${top} 收藏（门槛 ${minBm}），本次不发图`);
          return {
            content: (noData
              ? `翻了 ${cands.length} 个候选，但收藏数一个都没抓到（Pixiv 详情接口可能被限流），没法定按 ${minBm} 收藏筛选。`
              : `翻了 ${cands.length} 个候选，最高只有 ${top} 收藏，没达到你设的 ${minBm} 门槛，所以这次不发图。`)
              + '可以：① 把技能设置里的「最低收藏数」调低；② 把「搜索翻页数」调大（越往后翻越可能碰到攒够收藏的老图）；③ 换一个更热的日文标签。',
            isError: true
          };
        }
        pool = cands;
        relaxNote = noData
          ? '⚠️ 收藏数没抓到，本次放宽了门槛'
          : `⚠️ 候选最高只有 ${top} 收藏，未达 ${minBm} 门槛，本次已放宽`;
        log(`收藏门槛已放宽：翻了 ${cands.length} 个候选，最高 ${top} 收藏（门槛 ${minBm}）`);
      }

      // ★ 核心改动：选之前先按 PID 索引剔除爬过的
      const fresh = pool.filter((x) => !hasPid(x.id));
      const stale = pool.filter((x) => hasPid(x.id));

      let picked = weightedSelect(fresh, count);
      let reusedOld = false;
      if (picked.length < count && stale.length) {
        // 新图不够了：拿以前爬过的补，复用本地文件而不是重新下载
        picked = picked.concat(weightedSelect(stale, count - picked.length));
        reusedOld = true;
      }

      const folder = character.replace(/[^\w\u4e00-\u9fff-]/g, '_').slice(0, 24) || 'misc';
      const destDir = path.join(imageDir, folder);
      const sent = [];
      const failed = [];

      const showInfo = c.showInfo !== false;
      for (const it of picked) {
        try {
          const got = await downloadImage(it.url, destDir, {
            proxy, timeoutMs, name: folder, workId: it.id, pageCount: it.pageCount
          });
          if (!got) { failed.push(it.id); continue; }
          await ctx.sender.sendImage(ctx.chatKey, { file: got.file }, { note: `Pixiv ${it.id}` });
          // 作品信息紧跟图片单独发一条：图片气泡里塞不下文字，
          // 而模型的文本输出不会进 QQ，所以必须由工具自己发。
          if (showInfo) {
            try {
              await ctx.sender.sendTextBatch(ctx.chatKey, [relaxNote ? `${formatInfo(it)}\n${relaxNote}` : formatInfo(it)]);
            } catch { /* 信息发失败不该把"图已经发出去了"变成失败 */ }
          }
          sent.push({ pid: it.id, file: got.file, reused: got.reused, bm: it.bookmarks, author: it.author });
          recordPid(it.id, {
            file: got.file, folder, tags: it.tags.slice(0, 8), sent: true,
            author: it.author, title: it.title, bookmarks: it.bookmarks, likes: it.likes
          });
        } catch (e) {
          failed.push(it.id);
        }
      }

      if (!sent.length) {
        return {
          content: `找到 ${pool.length} 个作品，但都没能下载成功（可能是代理不稳）。稍后再试。`,
          isError: true
        };
      }

      const list = sent.map((s) => `PID ${s.pid}${s.bm ? `（收藏 ${s.bm}）` : ''}${s.reused ? '[复用已存的]' : ''}`).join('；');
      // mode=all 是全局设置：cookie 失效时照常发全年龄图，但必须在消息里说破，
      // 不然用户只会觉得"r18 设置不生效"（v1.2.0 之前就是这种静默降级）
      const modeNote = effectiveMode === 'safe' ? ''
        : loginState === 'no-cookie'
          ? '⚠️ 未配置 PHPSESSID，Pixiv 匿名搜索拿不到 R18，本次实际只搜了全年龄图。'
          : loginState === 'invalid'
            ? '⚠️ PHPSESSID 已失效，本次实际只搜了全年龄图——请到技能设置里重新复制。'
            : '';
      return {
        content: `已发送 ${sent.length} 张「${character}」的图（标签 ${jaTag}`
          + `${rawTag !== jaTag ? `，由「${rawTag}」自动规范化` : ''}`
          + `，耗时 ${Math.round((Date.now() - t0) / 1000)}s）：${list}。`
          + (reusedOld ? '其中包含以前爬过的作品——这个标签下的新图基本翻完了，改用已存图。' : '')
          + (failed.length ? `另有 ${failed.length} 张下载失败。` : '')
          + (relaxNote ? `${relaxNote}（配话时可以自然带一句，也可以不提。）` : '')
          + (modeNote ? `${modeNote}（配话时可以自然带一句，也可以不提。）` : '')
          + '图已经发出去了，你只要配一句短话，不要复述 PID 或标签。'
      };
    }
  });

  // 「测试按钮」的等价物：宿主的设置表单渲染器不支持按钮控件（configSchema 只有
  // boolean/number/enum/string/secret），所以把 cookie 自检做成一个工具——
  // 对机器人说「检查 pixiv cookie」就能触发，结论比按钮还细：未配置/已失效/R18未开启 三种都分得清。
  api.registerTool({
    id: 'pixiv_cookie_check',
    name: 'Pixiv 登录检查',
    description:
      '检查 Pixiv 技能的登录凭据（PHPSESSID）是否有效、R18 搜索是否可用。不发图、零副作用。' +
      '当用户说「检查 pixiv cookie」「测一下 pixiv 登录」「pixiv 的 r18 怎么搜不到」等排查类诉求时调用，并把结果转述给用户。',
    category: 'media',
    icon: '🍪',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const c = cfg() || {};
      const apiBase = String(c.apiBase || 'https://www.pixiv.net').trim().replace(/\/+$/, '');
      const proxy = String(c.proxy || '').trim();
      const timeoutMs = Math.min(60000, Math.max(5000, Number(c.timeoutMs) || 25000));
      const phpsessid = String(c.phpsessid || '').trim();
      const cookie = phpsessid ? `PHPSESSID=${phpsessid}` : '';

      if (proxy) {
        const pre = await ensureProxy({
          proxy, autoStart: c.autoStartProxy === true, coreDir: String(c.proxyCoreDir || '').trim()
        });
        if (!pre.ok) return { content: `检查不了：连不上代理（${pre.reason}）。先把代理弄好再测。`, isError: true };
      }
      if (!cookie) {
        return {
          content: '检查结果：❌ 未配置 Pixiv 登录凭据（PHPSESSID）。当前是匿名状态——全年龄搜图不受影响，'
            + '但 Pixiv 匿名拿不到任何 R18 内容（mode=all/r18 会被静默忽略，这也是"r18 不生效"最常见的原因）。'
            + '配置方法：浏览器登录 pixiv → F12 → Application → Cookie → https://www.pixiv.net → 复制 PHPSESSID 的值 → '
            + '粘贴到本技能设置的「Pixiv 登录凭据(PHPSESSID)」并保存。'
        };
      }
      if (await probeLoginState(cookie, { proxy, timeoutMs, apiBase }) !== 'ok') {
        return {
          content: '检查结果：❌ PHPSESSID 已失效（Pixiv 认为未登录）。请回浏览器重新复制一次'
            + '（F12 → Application → Cookie → https://www.pixiv.net → PHPSESSID），再到技能设置里更新保存。',
          isError: true
        };
      }
      const r18ok = await probeR18(cookie, { proxy, timeoutMs, apiBase });
      return {
        content: r18ok
          ? '检查结果：✅ PHPSESSID 有效，R18 搜索可用。'
          : '检查结果：⚠️ PHPSESSID 有效（登录正常），但 R18 搜索拿不到内容。多半是账号没开启 R18 显示：'
            + 'pixiv 网页 → 设置 → 阅览限制里开启后重测；账号年龄未满 18 岁是开不了的。',
        isError: !r18ok
      };
    }
  });
}

export function available() {
  return true;
}
