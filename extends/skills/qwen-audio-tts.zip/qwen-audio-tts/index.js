// 千问语音合成（LLM 型 / skills/）
//
// ── 为什么这是「技能」而不是「插件」 ──────────────────────────────────────
// 需求是"AI 想说语音时调用"。谁来判定"想"？只有模型自己 —— 所以必须
// registerTool 进模型的 function 列表，由模型决定何时调。放进 plugins/
// （确定性型）的话模型连这个工具都看不见，功能永远不触发。
//
// ── 一条语音的完整链路 ───────────────────────────────────────────────────
//   speak(text)
//     → 文本清洗（去 Markdown / emoji / 链接）      lib/text.js
//     → 定音色：
//         填了参考音频 URL → 复刻（首次）→ 缓存 voice_id   lib/voice-cache.js
//         没填           → 用配置里的系统音色
//     → 合成（非流式）拿到音频 URL                    lib/api.js
//     → 下载音频字节
//     → 交给 ctx.sender.sendMedia 发 record 段（协议端负责转 silk）
//
// ── 三个不能省的约束 ─────────────────────────────────────────────────────
// 1. 必须走 ctx.sender，不能直调 onebot.sendSegments：sender 才有串行队列、
//    限频、去重、留档。绕过它 = 语音能把文字配额吃光，而且下一轮模型不知道
//    自己发过语音（会重复发）。
// 2. 工具返回给模型的 content 是**短说明**，不是音频。音频塞进上下文既
//    花 token 又没有任何模型能"听"。
// 3. 复刻很贵（每次几秒 + 计费），必须缓存 voice_id，且缓存键带上模型 ——
//    音色不能跨模型用，模型变了旧 voice_id 必然 InvalidParameter。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from './lib/env.js';
import { createQwenClient } from './lib/api.js';
import { createVoiceCache, createSingleFlight, voiceCacheKey } from './lib/voice-cache.js';
import { resolveAudioSource } from './lib/audio-source.js';
import { cleanForSpeech, truncateForSpeech } from './lib/text.js';

/** 出厂默认值（与 skill.json 的 settings 必须一致，改一处要改两处）。 */
const DEFAULTS = {
  apiKey: '',
  baseUrl: 'https://maas.qianwenaiapi.com/api/v1',
  model: 'qwen-audio-3.0-tts-flash',
  voice: 'longanhuan_v3.6',
  referenceAudioUrl: '',
  voicePrefix: 'qqagent',
  language: 'zh',
  format: 'mp3',
  sampleRate: 24000,
  speed: 1,
  volume: 50,
  instruction: '',
  allowAiTuning: true,
  enablePreprocess: false,
  maxPromptAudioLength: 10,
  maxChars: 200
};

/** 合成音频的落盘目录（协议端要读本地文件，所以必须真实落盘）。 */
const AUDIO_DIR_NAME = 'qwen-audio-tts';
/** 合成音频的体积上限：一段 200 字的中文语音通常 200~600KB，15MB 足够。 */
const MAX_AUDIO_BYTES = 15 * 1024 * 1024;
/** 本地音频保留多久。QQ 语音发出去后协议端会转存，本地文件只是过渡。 */
const AUDIO_TTL_MS = 60 * 60 * 1000;

let api = null;
let log = () => {};
let client = null;
let voiceCache = null;
let singleFlight = null;

/** 当前设置（插件默认值 ← 用户在设置页改过的值）。 */
function settings() {
  const raw = (api && typeof api.config === 'function' ? api.config() : null) || {};
  const out = { ...DEFAULTS };
  for (const [k, v] of Object.entries(raw)) {
    if (v !== undefined && v !== null) out[k] = v;
  }
  // 环境变量兜底：没有在设置页填 Key 的用户常常已经把 Key 放在
  // DASHSCOPE_API_KEY 里（平台文档的默认约定）。只在配置为空时读。
  if (!String(out.apiKey || '').trim() && process.env.DASHSCOPE_API_KEY) {
    out.apiKey = String(process.env.DASHSCOPE_API_KEY);
  }
  return out;
}

/** 延迟构造客户端：fetch 来自 api，必须在 setup 之后才有。 */
function getClient() {
  if (!client) {
    client = createQwenClient({
      fetchImpl: (...args) => api.fetch(...args),
      baseUrl: () => settings().baseUrl,
      apiKey: () => settings().apiKey,
      log
    });
  }
  return client;
}

function getVoiceCache() {
  if (!voiceCache) {
    voiceCache = createVoiceCache({
      // 放在 data/ 下而不是技能目录里：技能目录随市场升级会被整体替换，
      // 缓存放里面每次升级都白丢一次复刻。
      dir: path.join(DATA_DIR, AUDIO_DIR_NAME),
      log
    });
  }
  return voiceCache;
}

/**
 * 决定这次用哪个音色。
 *
 * 两条路径：
 *   · 没有参考音频 → 直接用配置里的系统音色（零额外调用）
 *   · 有参考音频   → 查缓存 → 命中就用；没有就复刻一次并写缓存
 *
 * 复刻失败**不阻断**发言：降级到系统音色并告诉模型原因。理由是这个工具
 * 的交付目标是"把话说出来"，音色是增强项 —— 因为音色不对就一句都不说，
 * 用户体验反而更差。
 */
async function resolveVoice(cfg) {
  const reference = String(cfg.referenceAudioUrl || '').trim();
  if (!reference) {
    return { voice: String(cfg.voice || DEFAULTS.voice), cloned: false };
  }

  const cache = getVoiceCache();
  const key = voiceCacheKey({
    model: cfg.model,
    audioUrl: reference,
    prefix: cfg.voicePrefix,
    enablePreprocess: cfg.enablePreprocess,
    maxPromptAudioLength: cfg.maxPromptAudioLength,
    language: cfg.language
  });

  const hit = cache.get(key);
  if (hit) {
    cache.touch(key);
    return { voice: hit.voiceId, cloned: true, cached: true };
  }

  // 单飞：同一轮里连调两次 speak 时，第二个等第一个的复刻结果
  return singleFlight(key, async () => {
    // 双检：等锁期间可能已有别的调用写入了缓存
    const again = cache.get(key);
    if (again) {
      cache.touch(key);
      return { voice: again.voiceId, cloned: true, cached: true };
    }

    const prefix = String(cfg.voicePrefix || 'qqagent').replace(/[^a-zA-Z0-9]/g, '').slice(0, 10) || 'qqagent';
    try {
      const source = resolveAudioSource(reference);
      const { voiceId } = await getClient().createVoice({
        model: cfg.model,
        prefix,
        audioUrl: source.value,
        language: cfg.language,
        enablePreprocess: cfg.enablePreprocess,
        maxPromptAudioLength: cfg.maxPromptAudioLength
      });
      cache.put(key, { voiceId, model: cfg.model, audioUrl: reference });
      log(`[qwen-tts] 声音复刻成功：${voiceId}（参考音频 ${source.hint}）`);
      return { voice: voiceId, cloned: true, cached: false };
    } catch (error) {
      const msg = String(error?.message ?? error);
      log(`[qwen-tts] 声音复刻失败，改用系统音色 ${cfg.voice}：${msg}`);
      return {
        voice: String(cfg.voice || DEFAULTS.voice),
        cloned: false,
        fallbackReason: msg
      };
    }
  });
}

/**
 * 落盘合成好的音频，返回本地绝对路径。
 *
 * 为什么落盘而不是直接用 base64：把 300KB 的 base64 塞进 HTTP body 给协议端，
 * 协议端还要解码再上传；而传路径时协议端自己读磁盘，body 只有一百来字节。
 * 本项目默认协议端同机（127.0.0.1），这条路径收益最大。
 */
function saveAudio(buffer, format) {
  const dir = path.join(DATA_DIR, AUDIO_DIR_NAME);
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 14);
  const rand = Math.random().toString(36).slice(2, 8);
  const file = path.join(dir, `tts-${stamp}-${rand}.${String(format || 'mp3').replace(/[^a-z0-9]/gi, '') || 'mp3'}`);
  fs.writeFileSync(file, buffer);
  return file;
}

/** 清理过期音频（顺带清理上次运行崩掉留下的残渣）。失败不影响发言。 */
function pruneAudio() {
  try {
    const dir = path.join(DATA_DIR, AUDIO_DIR_NAME);
    if (!fs.existsSync(dir)) return;
    const now = Date.now();
    for (const name of fs.readdirSync(dir)) {
      if (!/^tts-[0-9a-z]+-[0-9a-z]+\.\w+$/.test(name)) continue;
      const p = path.join(dir, name);
      try {
        if (now - fs.statSync(p).mtimeMs > AUDIO_TTL_MS) fs.unlinkSync(p);
      } catch { /* 单个文件删不掉就算了 */ }
    }
  } catch { /* 清理是增强，不影响主流程 */ }
}

/**
 * 发送一条语音。
 *
 * 回退链（对应"语音发不出去"的三类真实原因）：
 *   ① 本地路径 —— 协议端自己读盘，最省
 *   ② base64   —— 协议端不同机 / 路径权限不足 / file:// 解析差异
 * 两种都失败才算失败，并把两段原因都带上（只报第一个会让人以为是格式问题）。
 *
 * 去重键用**朗读文本**而不是文件路径：每次合成的文件路径都是唯一的
 * （时间戳+随机），拿路径当键等于永远不去重 —— 模型一轮里连调两次
 * speak("晚安") 就会真的发两条一模一样的语音。核心的文本去重是按内容算的，
 * 语音也必须按内容算才对齐同一套语义。
 */
async function sendVoice(ctx, file, buffer, options = {}) {
  const dedupeKey = `tts:${String(options.text || '').slice(0, 200)}`;
  const segments = [{ type: 'record', data: { file } }];
  try {
    return await ctx.sender.sendMedia(ctx.chatKey, segments, {
      label: '[语音]',
      dedupeKey,
      replyToMessageId: options.replyToMessageId ?? null
    });
  } catch (firstError) {
    log(`[qwen-tts] 本地路径发语音失败（${firstError?.message ?? firstError}），改用 base64 重试`);
    const b64 = `base64://${buffer.toString('base64')}`;
    try {
      return await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'record', data: { file: b64 } }], {
        label: '[语音]',
        // 回退路径要换个键：否则会被上面那次失败前的"成功记账"挡住。
        // 但保留原文前缀，让"同文本连发"仍能被识别。
        dedupeKey: `${dedupeKey}#b64`,
        replyToMessageId: options.replyToMessageId ?? null
      });
    } catch (secondError) {
      throw new Error(`语音发送失败：本地路径=${firstError?.message ?? firstError}；base64=${secondError?.message ?? secondError}`);
    }
  }
}

/** 允许 AI 逐句调整的参数（白名单）。其余参数只认设置页。 */
const AI_TUNABLE_LANGUAGES = ['zh', 'en', 'ja', 'ko', 'fr', 'de', 'ru', 'pt', 'th', 'id', 'vi', 'es', 'it'];
/** 语气指令的长度上限：这是给模型的输入框，超长只会被服务端截断或忽略。 */
const MAX_INSTRUCTION_CHARS = 100;

/**
 * 合并"AI 逐句调整"与"设置页默认值"。
 *
 * 语义：**AI 传了就用 AI 的，没传就用设置页的**（按次覆盖，不改全局）。
 * 但每一层都校验 —— 模型的参数不是可信输入：
 *   · speed 超出 0.5~2.0 时服务端会报参数非法，这里先夹住
 *   · language 只认文档列出的枚举，别的值直接丢弃（拼错了不如不传）
 *   · instruction 截到 100 字，并去掉换行（它会被拼进指令位）
 * 管理员可以用「允许 AI 调整语气/语速/语言」一键关掉整条通道。
 */
function resolveTuning(cfg, args) {
  const allow = cfg.allowAiTuning !== false;
  const out = {
    instruction: String(cfg.instruction || '').trim(),
    speed: Number(cfg.speed) || 1,
    language: String(cfg.language || 'zh')
  };
  if (!allow) return { ...out, applied: [] };

  const applied = [];

  const rawInstruction = String(args?.instruction ?? '').replace(/[\r\n]+/g, ' ').trim();
  if (rawInstruction) {
    out.instruction = rawInstruction.slice(0, MAX_INSTRUCTION_CHARS);
    applied.push('instruction');
  }

  if (args?.speed !== undefined && args?.speed !== null && String(args.speed).trim() !== '') {
    const n = Number(args.speed);
    // 非数字/越界一律夹到合法区间，而不是报错 —— 语速错了没必要让整句发不出去
    if (Number.isFinite(n)) {
      out.speed = Math.min(2, Math.max(0.5, n));
      applied.push('speed');
    }
  }

  const rawLang = String(args?.language ?? '').trim().toLowerCase();
  if (rawLang && AI_TUNABLE_LANGUAGES.includes(rawLang)) {
    out.language = rawLang;
    applied.push('language');
  }

  return { ...out, applied };
}

export function setup(skillApi) {
  api = skillApi;
  log = skillApi.log;
  singleFlight = createSingleFlight();

  skillApi.registerTool({
    id: 'speak',
    name: '发语音',
    description: '把一段文字合成为语音消息发到当前聊天（文字转语音）。当有人要求"发条语音""用语音说""念给我听"，或你判断这句话用声音说更合适（撒娇、晚安、哄人、短句模仿口气）时调用。只传要念出来的正文：口语化、一到两句话、不要表情符号/括号动作/链接/Markdown/代码。一次调用只发一条语音。音色由管理员配置好，你不用管；需要语气变化时传 instruction（如"温柔一点"），需要放慢/加快时传 speed。',
    category: 'messaging',
    icon: '🔊',
    parameters: {
      type: 'object',
      properties: {
        text: {
          type: 'string',
          description: '要念出来的话（口语化短句，不要写表情符号、括号动作、链接、Markdown）。'
        },
        instruction: {
          type: 'string',
          description: '可选：语气/情绪/方言指令，如「温柔一点」「委屈的语气」「请讲上海话」。只写这一句的氛围要求，不要写台词本身。不传则用管理员的默认设置。'
        },
        speed: {
          type: 'number',
          description: '可选：语速倍数，0.5~2.0，1 是正常。想显得急切用 1.1~1.2，想显得慢或难过用 0.85~0.95。不传则用管理员的默认设置。'
        },
        language: {
          type: 'string',
          enum: ['zh', 'en', 'ja', 'ko', 'fr', 'de', 'ru', 'pt', 'th', 'id', 'vi', 'es', 'it'],
          description: '可选：朗读语言，决定数字/符号怎么念（如 "110" 念成"幺幺零"还是"one one zero"）。中文内容不用传；说英文/日文等外语句子时传对应语言。'
        },
        replyToMessageId: {
          type: ['integer', 'string'],
          description: '可选：要引用的消息 id（聊天记录里那条消息前的 #数字）。'
        }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try {
        const cfg = settings();

        const cleaned = cleanForSpeech(args?.text);
        if (!cleaned) {
          return { content: '错误：没有可朗读的内容（清洗后为空：可能只有表情符号/链接/代码）。请传一句正常的话。', isError: true };
        }
        const { text, truncated } = truncateForSpeech(cleaned, cfg.maxChars);

        // 先清一次旧文件，再合成 —— 避免磁盘被历史语音堆满
        pruneAudio();

        const voiceInfo = await resolveVoice(cfg);
        const tuning = resolveTuning(cfg, args);

        const synth = await getClient().synthesize({
          model: cfg.model,
          text,
          voice: voiceInfo.voice,
          format: cfg.format,
          sampleRate: cfg.sampleRate,
          volume: cfg.volume,
          rate: tuning.speed,
          language: tuning.language,
          instruction: tuning.instruction
        });

        const buffer = await getClient().downloadAudio(synth.url, { maxBytes: MAX_AUDIO_BYTES });
        const file = saveAudio(buffer, cfg.format);
        const sent = await sendVoice(ctx, file, buffer, {
          replyToMessageId: args?.replyToMessageId,
          text
        });

        // 留档：让下一轮知道自己发过语音（否则模型可能重复发同一句）
        ctx.session?.sent?.push({
          type: 'record',
          text: `[语音] ${text}`,
          at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
        });
        try { ctx.emit?.('session-update', ctx.session?.id); } catch { /* 事件失败不影响结果 */ }

        const notes = ['语音已发送。不要输出"已发送"类汇报，继续思考下一步或直接结束。'];
        if (truncated) notes.push(`（原文超过 ${cfg.maxChars} 字，已截到「${text.slice(-12)}…」附近；要说完请分多次调用）`);
        if (voiceInfo.fallbackReason) notes.push(`（声音复刻没成功，本次用系统音色：${voiceInfo.fallbackReason}）`);
        if (voiceInfo.cloned && !voiceInfo.cached) notes.push('（本次首次使用参考音频复刻音色，之后会复用）');
        // 只报"真正生效的逐句调整"，方便模型确认自己的语气要求有没有被采纳
        if (tuning.applied.length) notes.push(`（本次按你的要求调整了：${tuning.applied.join('、')}）`);
        else if (cfg.allowAiTuning === false) notes.push('（管理员已关闭逐句语气调整，本次用全局设置）');

        return {
          content: JSON.stringify({
            sent: true,
            chars: synth.characters || text.length,
            voice: voiceInfo.voice,
            cloned: voiceInfo.cloned === true,
            // 回显实际生效的合成参数，模型据此判断"我说的温柔有没有用上"
            applied: { instruction: tuning.instruction || null, speed: tuning.speed, language: tuning.language },
            messageId: sent?.message_id ?? null,
            note: notes.join('')
          }, null, 1)
        };
      } catch (error) {
        return { content: `错误：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

/**
 * 同步自检（可用性判定走同步链，返回 Promise 会被当成"可用"）。
 *
 * 只查"配置齐不齐"，不探测网络 —— 探测会把网络抖动变成"工具集抖动"，
 * 进而让会话判定 fresh、缓存全不命中（见 caching-contract.md 铁律三）。
 * Key 缺失时明确不可用，比"工具看得见但每次调用都 401"好得多。
 */
export function available() {
  const cfg = settings();
  if (!String(cfg.apiKey || '').trim()) {
    return { ok: false, reason: '未配置千问 API Key（设置 → 千问语音合成 → 千问 API Key，或环境变量 DASHSCOPE_API_KEY）' };
  }
  if (!String(cfg.model || '').trim()) return { ok: false, reason: '未配置合成模型' };
  return { ok: true };
}

/** 热重载/卸载时把缓存的客户端与单飞状态清掉，避免抓着旧的 api.fetch。 */
export function dispose() {
  client = null;
  voiceCache = null;
  singleFlight = null;
}
